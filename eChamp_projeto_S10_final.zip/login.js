const formLogin = document.getElementById("formLogin");
const mensagemLogin = document.getElementById("mensagemLogin");
const esqueciSenha = document.getElementById("esqueciSenha");

formLogin.addEventListener("submit", function (event) {
    event.preventDefault();

    const usuario = document.getElementById("usuario").value.trim();
    const senha = document.getElementById("senha").value.trim();

    mensagemLogin.className = "mensagem";

    if (!usuario || !senha) {
        mensagemLogin.textContent = "Preencha o usuário/e-mail e a senha.";
        mensagemLogin.classList.add("erro");
        return;
    }

    // Credencial de demonstração exigida pela atividade.
    if (usuario === "teste" && senha === "123") {
        mensagemLogin.textContent = "Login realizado com sucesso!";
        mensagemLogin.classList.add("sucesso");

        sessionStorage.setItem("echampUsuario", usuario);

        setTimeout(() => {
            window.location.href = "area-restrita.html";
        }, 500);
        return;
    }

    mensagemLogin.textContent = "Credenciais inválidas. Tente novamente.";
    mensagemLogin.classList.add("erro");
});

esqueciSenha.addEventListener("click", function (event) {
    event.preventDefault();
    mensagemLogin.className = "mensagem sucesso";
    mensagemLogin.textContent = "A recuperação de senha será disponibilizada em uma versão futura.";
});
